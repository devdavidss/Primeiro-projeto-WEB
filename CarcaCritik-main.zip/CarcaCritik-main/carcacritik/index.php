<!DOCTYPE html>
<?php
//comeco da sessao.
session_start();
?>
<html lang="pt-br">
        <head>
        <meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1.0"/>
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
                <link rel="stylesheet" href="css/style_clr.css"/>

                <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
                <script src="src/javascript/script.js"></script>

                <link rel="preconnect" href="https://fonts.googleapis.com">
                <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
                <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed&family=Roboto:wght@300&display=swap" rel="stylesheet">
                <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
                <style>@import url('https://fonts.googleapis.com/css2?family=Barlow:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap');</style>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" integrity="sha512-bLT0Qm9VnAYZDflyKcBaQ2gg0hSYNQrJ8RilYldYQ1FxQYoCLtUjuuRuZo+fjqhx/qtq/1itJ0C2ejDxltZVFg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
                <script src="https://unpkg.com/scrollreveal"></script>

                <title>Registro</title>
        </head>
<body>
        <div class="col-md-6 well">
                <h3 class="text-primary">Login e Registro</h3>
                <hr style="border-top:1px dotted #ccc;"/>
                <!-- Link para redirecionar para a pagina de inicio -->
                <a href="home.php">Inicio clique aqui...</a>
                <!-- Link para redirecionar para a pagina de login -->
                <a href="login.php">Já  e um Membro? Login aqui...</a>
                <br style="clear:both;"/><br />
                <div class="col-md-6">
                        <!-- Comeco do formulario de registro -->
                        <form method="POST" action="save_user.php">  
                                <div class="alert alert-info">Registro</div>
                                <div class="form-group">
                                        <label>Usuario</label>
                                        <input type="text" name="usuario" class="form-control" required="required"/>
                                </div>
                                <div class="form-group">
                                        <label>Senha</label>
                                        <input type="password" name="senha" class="form-control" required="required"/>
                                </div>
                                <?php
                                        //checando se a session 'success' esta estabelecida.
                                        if(ISSET($_SESSION['success'])){
                                ?>
                                <!-- Mostrar mensagem de registrado com sucesso  -->
                                <div class="alert alert-success"><?php echo $_SESSION['success']?></div>
                                <?php
                                        //Desconfigurando a session 'success' após exibir a mensagem.
                                        unset($_SESSION['success']);
                                        }
                                ?>
                                <button class="btn btn-primary btn-block" name="registro"><span class="glyphicon glyphicon-save"></span> Registrar</button>
                        </form>
                        <!-- Fim do formulario de registro -->
                </div>
        </div>
</body>
</html>